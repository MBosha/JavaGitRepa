package io.hexlet.xo.model;


public enum Figure {

    X, O

}
