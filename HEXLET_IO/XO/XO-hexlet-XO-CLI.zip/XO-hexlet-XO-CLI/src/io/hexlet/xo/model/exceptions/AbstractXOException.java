package io.hexlet.xo.model.exceptions;


public abstract class AbstractXOException extends Exception {
}
